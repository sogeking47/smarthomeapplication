package com.example.myapplication;

public class lock {
    private String status;

    public lock() {
    }

    public lock(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
